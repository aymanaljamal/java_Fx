package application;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;

public class ShapeExample extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // إنشاء مستطيل
        Shape rectangle = new javafx.scene.shape.Rectangle(50, 50, 100, 80);
        rectangle.setFill(Color.BLUE);
        rectangle.setRotate(48);
        StackPane root = new StackPane();
        root.getChildren().add(rectangle);

        Scene scene = new Scene(root, 200, 150);
        primaryStage.setTitle("Shape Example");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
